require 'rspec/mocks'
extend RSpec::Mocks::ExampleMethods
RSpec::Mocks.setup
