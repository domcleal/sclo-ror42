RSpec provides a few features that, while not generally recommended, can be useful when
you are getting legacy code under test (or in similar situations). Usage of these features
should be considered a code smell.
