module Rake
  class TaskLib
  end
end
