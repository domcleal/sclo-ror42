module RR
  module Errors
    BACKTRACE_IDENTIFIER = /doesn't matter/
  end

  module Extensions
    module InstanceMethods
    end
  end
end
