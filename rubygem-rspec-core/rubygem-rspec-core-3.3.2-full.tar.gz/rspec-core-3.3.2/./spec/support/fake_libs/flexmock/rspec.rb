module FlexMock
  module MockContainer
  end
end
