module Minitest
  module Assertions
  end
end
