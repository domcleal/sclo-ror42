# encoding: utf-8
module Custom
  class ExampleUTF8ClassNameVarietà
    def self.è
      così = :però
      così
    end
  end
end
