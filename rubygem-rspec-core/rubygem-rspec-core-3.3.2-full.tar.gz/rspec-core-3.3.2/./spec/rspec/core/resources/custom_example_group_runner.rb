module Custom
  class ExampleGroupRunner
    attr_reader :options, :arg
    def initialize(options, arg)
      @options, @arg = options, arg
    end

    def load_files(files)
    end

    def run
    end
  end
end
