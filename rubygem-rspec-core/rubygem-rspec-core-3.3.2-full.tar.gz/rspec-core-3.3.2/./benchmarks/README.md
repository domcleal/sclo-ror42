## Benchmarks

This directory contains various benchmarks we used to inform implementation
decisions.
