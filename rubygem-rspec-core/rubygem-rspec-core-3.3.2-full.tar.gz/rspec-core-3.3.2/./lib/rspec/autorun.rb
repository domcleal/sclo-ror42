require 'rspec/core'
# Ensure the default config is loaded
RSpec::Core::Runner.autorun
