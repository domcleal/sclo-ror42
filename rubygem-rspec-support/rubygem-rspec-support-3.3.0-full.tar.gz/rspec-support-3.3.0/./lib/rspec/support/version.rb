module RSpec
  module Support
    module Version
      STRING = '3.3.0'
    end
  end
end
