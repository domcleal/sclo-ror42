describe "something" do
  it "does something that passes" do
    1.should eq(1)
  end

  it "does something that fails" do
    1.should eq(2)
  end
end
