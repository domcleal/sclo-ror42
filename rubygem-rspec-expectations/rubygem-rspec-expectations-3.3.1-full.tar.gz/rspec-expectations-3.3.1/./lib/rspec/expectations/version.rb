module RSpec
  module Expectations
    # @private
    module Version
      STRING = '3.3.1'
    end
  end
end
